import Slider from "../components/Sldier"
import Products from "../components/product/Products"
export default function Home(){
    return(
        <div>
            <Slider/>
            <Products/>
        </div>
    )
}
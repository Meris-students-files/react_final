export default function NotExist(){
    return(<div>
        Page does not exist
    </div>)
}
import logo from './logo.svg';
import './App.css';
import './global.css';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from './pages/Layout';
import Home from './pages/Home';
import Cart from './pages/Cart';
import WhishList from './pages/Whishlist';
import NotExist from './pages/NotExist';
import ProductPage from './pages/Product';
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Layout/>}>
          <Route index element={<Home/>}></Route>
          <Route path='home' element={<Home/>}></Route>
          <Route path='cart' element={<Cart/>}></Route>
          <Route path='whishList' element={<WhishList/>}></Route>
          <Route path='product' element={<ProductPage/>}></Route>

        </Route>
        <Route path='*' element={<NotExist/>}></Route>

      </Routes>
    </BrowserRouter>
  );
}

export default App;

export default{
    items: JSON.parse(localStorage.getItem('cart')) || []
}